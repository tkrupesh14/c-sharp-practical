﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Practial_Project_1
{
    public partial class Form1 : Form
    {
        OleDbCommand cmd;
        OleDbConnection con;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + "\\employee.mdb");
            con.Open();
            getdata();
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            if(txtno.Text == "" || txtname.Text == "")
            {
                MessageBox.Show("Please Enter Values", "Empty Value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }else
            {
                cmd = new OleDbCommand("insert into emp_details values (" + int.Parse(txtno.Text)+ ", ' " + txtname.Text + " ' )", con);
                int result = cmd.ExecuteNonQuery();
                if(result > 0)
                {
                    MessageBox.Show("Data Entered Successfully", "Inserted Value", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    getdata();
                }
            }
        }

        private void txtno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar >= 49 && e.KeyChar <= 57)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Please Enter Only Numbers", "Other Value", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void txtname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 49 && e.KeyChar <= 57)
            {
                e.Handled = true;
                MessageBox.Show("Please Enter Only Characters", "Other Value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                e.Handled = false;
              

            }
        }
        public void getdata()
        {
            cmd = new OleDbCommand("select emp_no as 'NO' ,emp_name as 'NAME' from emp_details", con);
            OleDbDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;

        }
    }
    }


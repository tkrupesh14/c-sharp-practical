﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stopwatch
{
    public partial class Form1 : Form
    {
        int no;
        public Form1()
        {
            InitializeComponent();
        }

      

        private void Form1_Load(object sender, EventArgs e)
        {
            btnpause.Enabled = false;
            btnstop.Enabled = false;
        }

        private void btnplay_Click(object sender, EventArgs e)
        {
            btnpause.Enabled = true;
            btnstop.Enabled = true;
            btnplay.Enabled = false;
            timer1.Start();
        }

        private void btnpause_Click(object sender, EventArgs e)
        {
            btnplay.Enabled = true;
            btnstop.Enabled = true;
            btnpause.Enabled = false;
            timer1.Stop();
        }

        private void btnstop_Click(object sender, EventArgs e)
        {
            btnplay.Enabled = true;
            btnpause.Enabled = true;
            btnstop.Enabled = false;
            lblcounter.Text = "0";
            no = 0;
            timer1.Stop();
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            no++;
            lblcounter.Text = no.ToString();
        }
    }
}
